# Hology Interactive AB Limited License

This software package, including all associated files and documentation (the "Software"), is licensed to you (the "Licensee") by Hology Interactive AB for use exclusively with the product "Hology Engine."

By using, copying, modifying, or distributing the Software, Licensee agrees to be bound by the terms of this license.

1. License Grant: Hology Interactive AB grants Licensee a limited, non-exclusive, non-transferable license to use the Software solely for the purpose of developing and running software developed with "Hology Engine."

2. Restrictions: Licensee may not use, copy, modify, or distribute the Software for any other purpose, including but not limited to the creation of derivative works, standalone applications, or any products not directly associated with "Hology Engine."

3. Ownership: Hology Interactive AB retains all intellectual property rights to the Software. This license does not transfer ownership of the Software to Licensee.

4. Warranty Disclaimer: THE SOFTWARE IS PROVIDED "AS IS," WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. IN NO EVENT SHALL THE CREATOR OF THIS PACKAGE BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE.

6. Contact: For any inquiries regarding this license, please email hello@hology.app