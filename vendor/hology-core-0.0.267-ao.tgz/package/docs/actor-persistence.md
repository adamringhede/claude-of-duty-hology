# Actor persistence

Persistence is opt-in and storage-independent. Enable it when loading a single-player session:

```ts
await application.loadGame(Game, {
  sceneName: save.sceneName,
  persistence: { data: save.persistence }, // undefined data starts an empty document
})
```

`initiateGame()` and React's `HologyScene` accept the same `persistence` option. Games load and migrate their save envelope before loading the scene, then write `inject(ActorPersistence).snapshot()` alongside their other save data. Capture is synchronous and returns detached JSON data; do it before awaiting storage. Sessions without this option do not register actors. Network sessions reject the option.

## Actor and component hooks

```ts
@Actor({ persistent: true })
class Chest extends BaseActor implements PersistentState<{ opened: boolean }> {
  readonly persistenceVersion = 1
  opened = false

  onCapturePersistence() { return { opened: this.opened } }
  onRestorePersistence(state: { opened: boolean }, context: PersistenceContext) {
    if (context.version !== 1 || typeof state?.opened !== 'boolean') {
      throw new Error('Unsupported chest state')
    }
    this.opened = state.opened
  }
  onPersistenceRestored() { this.updateAppearance() }
}

@Component()
class Cooldown extends ActorComponent implements PersistentState<{ remaining: number }> {
  // Stable within the owning actor, including nested components. Two cooldowns
  // need distinct keys, e.g. 'primary-attack' and 'dodge'. Never use array indices.
  persistenceKey = 'primary-attack'
  readonly persistenceVersion = 1
  remaining = 0

  onCapturePersistence() { return { remaining: this.remaining } }
  onRestorePersistence(state: { remaining: number }, context: PersistenceContext) {
    if (context.version !== 1 || !Number.isFinite(state?.remaining)) {
      throw new Error('Unsupported cooldown state')
    }
    this.remaining = Math.max(0, state.remaining)
  }
}
```

Override `get persistenceEnabled()` for a policy based on authored parameters (for example, enemy faction). It is evaluated after initialization. A component never opts its actor in. An opted-in actor may have only component hooks, or no hooks if it only needs permanent removal.

For the common position-and-yaw case, attach `ActorTransformPersistenceComponent` to an opted-in actor. It uses the stable component key `transform` and stores local position and yaw, leaving pitch and roll at their authored values. It restores before begin-play and synchronizes an existing physics body after the restore batch. Attach it only once per actor. `captureActorTransform(actor)` and `restoreActorTransform(actor, state)` provide the same JSON shape for custom hooks; the latter validates the payload and sets the object transform, so custom movement systems must also synchronize their own state and physics. A character movement component, for example, can call `movement.teleport(actor.position, actor.rotation.y)` in the actor's `onPersistenceRestored()` when a saved transform was applied (`transformComponent.restored`).

Initialize defaults in `onInit()`. Restore runs after all actors/components initialize and references bind, before `onBeginPlay()`, event graphs, game preload and presentation. Do not reset persisted fields in begin-play. Components restore before their actor. `onPersistenceRestored()` runs after the entire batch restores, including actors with no saved entry. Ordinary restore hooks may resolve other actors, but cannot assume those actors have restored yet. Hooks should not spawn participants or mutate the batch.

Save finite JSON values, not actors, vectors, signals, functions, dates or cyclic objects. Validate or migrate component/actor payload versions in the restore hook. Unknown component entries are retained for later saves. Restore failures stop loading and include identity and component key in the error. Restore by assigning state, without replaying damage, death, item rewards or other gameplay events. Save remaining durations rather than wall-clock deadlines unless the game intentionally advances them while closed.

## Identity and removal

Authored identities are `{ sceneId, path }`: the stable scene metadata ID and the existing object/prefab instance path. Names are not IDs. Renaming does not change identity; recreating an object or moving it across prefab boundaries may require a game save migration.

Call `persistence.markRemoved(actor)` at the permanent gameplay outcome, such as enemy death, before delayed presentation cleanup. It records removal without destroying the live object. The materializer skips that authored subtree on the next load. For a prefab's exposed actor, this removes the whole exposed placement, including nested prefabs, meshes, collisions and event graphs. Ordinary `world.removeActor()` and unloading capture state but never mark it removed.

References to removed actors become `null`. Gameplay must handle that possibility. `getIdentity(actor)`, `resolve(identity)` and `isRemoved(identity)` support game save references. Scene parameters can use direct actor references, including arrays; a removed actor resolves to `null` in the corresponding field.

Scene travel captures outgoing actors and retains unloaded scene records. Game-lifetime actors remain registered and are not restored again when their authored scene is revisited.

## Dynamic actors

The game saves its own spawn descriptors and recreates actors/prefabs explicitly:

```ts
await world.spawnActor(Companion, position, rotation, { persistenceId: 'quest-companion' })
await world.spawnPrefab(droppedItemPrefab, position, rotation, { persistenceId: savedDrop.id })
```

The actor must still opt in. Dynamic identities are `{ dynamicId, path }`, with an empty path for the main actor and prefab-local paths for other actors. IDs are unique across the session, independent of scene. The game decides which scene to spawn them in. A removed or already active ID is an error; use `isRemoved({ dynamicId, path: '' })` before recreating it. All actors in a prefab restore before any begin-play. References across separately spawned dynamic actors require game-controlled creation order. Synchronous spawning cannot restore persistent state.

The engine does not recreate dynamically attached components. The game must attach them with stable keys before restoration. Dynamic prefabs are removed as a unit when any persistent member is marked removed.

## Cost and testing

Persistence has no frame callback. Nonparticipating actors receive no persistence record or subscription. Discovery occurs at initialization/capture/restore boundaries, and snapshots traverse registered actors only. Snapshot size and capture frequency remain under game control.

Core checks: `npm test -- --run src/test/actor-persistence.test.ts src/test/actor-persistence-runtime.test.ts src/test/world-lifecycle.test.ts src/test/world-prefab-spawn.test.ts src/test/prefab-instance-params.test.ts src/test/rendering-host.test.ts` from `packages/core`.

Maran integration checks, with both repositories side by side: `npm exec -- vitest run --config ../../../legend-of-maran/tests/persistence.config.mts` from `packages/core`.
