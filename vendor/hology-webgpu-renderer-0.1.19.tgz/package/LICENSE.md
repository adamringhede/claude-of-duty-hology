### Hology Interactive AB Limited License

Copyright (c) 2026 Hology Interactive AB. All rights reserved.

This software package, including all associated files and documentation (the
"Software"), is licensed under the following terms:

1. **License Grant**
   Hology Interactive AB grants Licensee a limited, non-exclusive,
   non-transferable license to use the Software solely for the purpose of
   developing and running software within the Hology Engine ecosystem.

2. **Restrictions**
   - Licensee may not use, copy, modify, or distribute the Software for any
     purpose outside of Hology Engine.
   - Licensee may not create derivative works of the Software that function
     independently of Hology Engine.
   - Licensee must not remove or alter any licensing notices.

3. **Ownership**
   Hology Interactive AB retains all intellectual property rights to the
   Software. This license does not transfer ownership of the Software.

4. **Warranty Disclaimer**
   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT. HOLOGY INTERACTIVE AB
   SHALL NOT BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM
   THE USE OF THE SOFTWARE.

5. **Contact**
   For inquiries regarding this license, please email hello@hology.app.
